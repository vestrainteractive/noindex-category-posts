# noindex-category-posts

Simple plugin to add no-index to posts in a specific wordpress category.

NOTE:  RANK MATH is **REQUIRED** for this plugin to work.  Further, basic php knowledge is required to edit the required files.  If you are not comfortable editing PHP files, please consult a developer.  No free support is offered for this plugin.

To use:

Download the plugin and open the noindex-category-posts.php file in a text editor.

Edit the array on line 24, replacing 'your','category','here' with your required categories.

Save and upload the plugin as normal.

Activate the plugin.
